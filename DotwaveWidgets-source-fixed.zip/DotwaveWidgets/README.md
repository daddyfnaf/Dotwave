# Dotwave Widgets

Android widget pack with a Material You + Nothing-inspired visual style.

## Widgets
- **Music player**: album art, track title/artist, playback controls, progress and lyrics (where available).
- **Dot Clock 4×1**: horizontal clock and date widget designed for the top row of the home screen. It uses the system's dynamic Material color attributes.

## Build
Open the project in Android Studio and build the `app` debug variant. The project requires Android SDK 36 and JDK 17.

The clock widget is configured for a 4-column by 1-row launcher placement. Actual cell sizing can vary slightly by launcher and grid configuration; it can be resized horizontally if the launcher permits.

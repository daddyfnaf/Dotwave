package dev.dotwave.widgets;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class LyricsClient {
    private static final Pattern LRC_LINE = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\](.*)");

    private LyricsClient() {}

    static String fetch(String title, String artist, String album, long durationMs) {
        HttpURLConnection connection = null;
        try {
            String query = "track_name=" + enc(title)
                    + "&artist_name=" + enc(artist)
                    + "&album_name=" + enc(album == null ? "" : album);
            if (durationMs > 0) query += "&duration=" + Math.max(1, durationMs / 1000L);
            URL url = new URL("https://lrclib.net/api/get?" + query);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(7000);
            connection.setRequestProperty("User-Agent", "DotwaveWidgets/1.0 (Android music widget)");
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) return "";
            try (InputStream input = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                JSONObject json = new JSONObject(body.toString());
                String synced = json.optString("syncedLyrics", "");
                if (!synced.trim().isEmpty()) return synced;
                return json.optString("plainLyrics", "");
            }
        } catch (Exception ignored) {
            return "";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    static String currentLine(String lyrics, long positionMs) {
        if (lyrics == null || lyrics.trim().isEmpty()) return "Lyrics not found for this track";
        String[] lines = lyrics.split("\\r?\\n");
        List<TimedLine> timed = new ArrayList<>();
        StringBuilder plain = new StringBuilder();

        for (String line : lines) {
            Matcher matcher = LRC_LINE.matcher(line.trim());
            if (matcher.matches()) {
                long minutes = Long.parseLong(matcher.group(1));
                long seconds = Long.parseLong(matcher.group(2));
                String fraction = matcher.group(3);
                long millis = 0;
                if (fraction != null) {
                    if (fraction.length() == 1) millis = Long.parseLong(fraction) * 100L;
                    else if (fraction.length() == 2) millis = Long.parseLong(fraction) * 10L;
                    else millis = Long.parseLong(fraction.substring(0, 3));
                }
                timed.add(new TimedLine(minutes * 60000L + seconds * 1000L + millis, matcher.group(4).trim()));
            } else if (!line.trim().isEmpty()) {
                if (plain.length() > 0) plain.append(" · ");
                plain.append(line.trim());
            }
        }

        if (timed.isEmpty()) {
            if (plain.length() == 0) return "Lyrics will appear here";
            String text = plain.toString();
            return text.length() > 110 ? text.substring(0, 107) + "…" : text;
        }

        String current = "♪";
        for (TimedLine item : timed) {
            if (item.timeMs <= positionMs) current = item.text;
            else break;
        }
        return current.isEmpty() ? "♪" : current;
    }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
    }

    private static final class TimedLine {
        final long timeMs;
        final String text;
        TimedLine(long timeMs, String text) { this.timeMs = timeMs; this.text = text; }
    }
}

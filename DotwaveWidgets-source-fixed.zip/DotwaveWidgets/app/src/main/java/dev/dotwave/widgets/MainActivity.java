package dev.dotwave.widgets;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends Activity {
    private TextView accessStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accessStatus = findViewById(R.id.access_status);
        MaterialButton accessButton = findViewById(R.id.grant_access);
        MaterialButton refreshButton = findViewById(R.id.refresh_widgets);

        accessButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (Exception ignored) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        refreshButton.setOnClickListener(v -> refreshAllWidgets());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessStatus();
        refreshAllWidgets();
    }

    private void updateAccessStatus() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), "enabled_notification_listeners");
        boolean granted = !TextUtils.isEmpty(enabled)
                && enabled.contains(getPackageName() + "/" + MusicNotificationListener.class.getName());
        accessStatus.setText(granted
                ? "Music access: connected ✓"
                : "Music access: not connected");
    }

    private void refreshAllWidgets() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        int[] musicIds = manager.getAppWidgetIds(new ComponentName(this, MusicWidgetProvider.class));
        if (musicIds.length > 0) {
            new MusicWidgetProvider().onUpdate(this, manager, musicIds);
        }
        int[] clockIds = manager.getAppWidgetIds(new ComponentName(this, ClockWidgetProvider.class));
        if (clockIds.length > 0) {
            new ClockWidgetProvider().onUpdate(this, manager, clockIds);
        }
    }
}

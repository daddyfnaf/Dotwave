package dev.dotwave.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

public class MusicWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateOne(context, manager, id);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, MusicWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_music);
        android.content.SharedPreferences prefs = PlayerStateStore.prefs(context);

        views.setTextViewText(R.id.track_title, prefs.getString("title", "Nothing playing"));
        views.setTextViewText(R.id.track_artist, prefs.getString("artist", "Start music to connect"));
        views.setTextViewText(R.id.lyric_line, prefs.getString("lyric", "Lyrics will appear here"));

        long duration = prefs.getLong("duration", 0L);
        long position = prefs.getLong("position", 0L);
        int progress = duration > 0 ? (int) Math.min(1000L, (position * 1000L) / duration) : 0;
        views.setProgressBar(R.id.track_progress, 1000, progress, false);
        views.setTextViewText(R.id.action_toggle, prefs.getBoolean("playing", false) ? "Ⅱ" : "▶");

        Bitmap artwork = PlayerStateStore.loadArtwork(context);
        if (artwork != null) views.setImageViewBitmap(R.id.album_art, artwork);

        views.setOnClickPendingIntent(R.id.action_previous, action(context, WidgetActionReceiver.ACTION_PREVIOUS, 101));
        views.setOnClickPendingIntent(R.id.action_toggle, action(context, WidgetActionReceiver.ACTION_TOGGLE, 102));
        views.setOnClickPendingIntent(R.id.action_next, action(context, WidgetActionReceiver.ACTION_NEXT, 103));

        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(context, 104, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.music_root, openPending);

        manager.updateAppWidget(id, views);
    }

    private static PendingIntent action(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, WidgetActionReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}

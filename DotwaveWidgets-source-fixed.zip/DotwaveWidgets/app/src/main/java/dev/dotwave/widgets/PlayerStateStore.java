package dev.dotwave.widgets;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;

import java.io.File;
import java.io.FileOutputStream;

final class PlayerStateStore {
    private static final String PREFS = "dotwave_player";
    private static final String ART_FILE = "dotwave_album_art.png";

    private PlayerStateStore() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void save(Context context, MediaController controller) {
        if (controller == null) {
            prefs(context).edit()
                    .putString("title", "Nothing playing")
                    .putString("artist", "Start music to connect")
                    .putString("lyric", "Lyrics will appear here")
                    .putBoolean("playing", false)
                    .putLong("position", 0L)
                    .putLong("duration", 0L)
                    .apply();
            return;
        }

        MediaMetadata metadata = controller.getMetadata();
        PlaybackState playback = controller.getPlaybackState();
        String title = metadata == null ? "Unknown track" : metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = metadata == null ? "Unknown artist" : metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        String album = metadata == null ? "" : metadata.getString(MediaMetadata.METADATA_KEY_ALBUM);
        long duration = metadata == null ? 0L : metadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long position = playback == null ? 0L : Math.max(0L, playback.getPosition());
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING;

        if (playing && playback != null && playback.getLastPositionUpdateTime() > 0) {
            long elapsed = android.os.SystemClock.elapsedRealtime() - playback.getLastPositionUpdateTime();
            position += (long) (elapsed * playback.getPlaybackSpeed());
        }
        if (duration > 0) position = Math.min(position, duration);

        SharedPreferences p = prefs(context);
        p.edit()
                .putString("title", emptyFallback(title, "Unknown track"))
                .putString("artist", emptyFallback(artist, "Unknown artist"))
                .putString("album", emptyFallback(album, ""))
                .putBoolean("playing", playing)
                .putLong("position", position)
                .putLong("duration", duration)
                .apply();

        if (metadata != null) {
            String artKey = title + "\u001f" + artist + "\u001f" + album;
            String previousArtKey = p.getString("art_track_key", "");
            if (!artKey.equals(previousArtKey)) {
                Bitmap art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                if (art != null) saveArtwork(context, art);
                else new File(context.getFilesDir(), ART_FILE).delete();
                p.edit().putString("art_track_key", artKey).apply();
            }
        }
    }

    static Bitmap loadArtwork(Context context) {
        File file = new File(context.getFilesDir(), ART_FILE);
        return file.exists() ? BitmapFactory.decodeFile(file.getAbsolutePath()) : null;
    }

    static void saveLyrics(Context context, String trackKey, String lyrics) {
        prefs(context).edit()
                .putString("lyrics_track_key", trackKey)
                .putString("lyrics_raw", lyrics == null ? "" : lyrics)
                .apply();
    }

    static String getLyrics(Context context) {
        return prefs(context).getString("lyrics_raw", "");
    }

    static String getLyricsTrackKey(Context context) {
        return prefs(context).getString("lyrics_track_key", "");
    }

    static void setCurrentLyric(Context context, String lyric) {
        prefs(context).edit().putString("lyric", emptyFallback(lyric, "Lyrics not found" )).apply();
    }

    private static void saveArtwork(Context context, Bitmap bitmap) {
        Bitmap scaled = bitmap;
        if (bitmap.getWidth() > 320 || bitmap.getHeight() > 320) {
            scaled = Bitmap.createScaledBitmap(bitmap, 320, 320, true);
        }
        try (FileOutputStream out = context.openFileOutput(ART_FILE, Context.MODE_PRIVATE)) {
            scaled.compress(Bitmap.CompressFormat.PNG, 90, out);
        } catch (Exception ignored) {
            // A missing cover should never interrupt media controls.
        } finally {
            if (scaled != bitmap && !scaled.isRecycled()) scaled.recycle();
        }
    }

    private static String emptyFallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}

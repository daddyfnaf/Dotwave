package dev.dotwave.widgets;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;

public class WidgetActionReceiver extends BroadcastReceiver {
    static final String ACTION_PREVIOUS = "dev.dotwave.widgets.PREVIOUS";
    static final String ACTION_TOGGLE = "dev.dotwave.widgets.TOGGLE";
    static final String ACTION_NEXT = "dev.dotwave.widgets.NEXT";

    @Override
    public void onReceive(Context context, Intent intent) {
        MediaController controller = MusicNotificationListener.findActiveController(context);
        if (controller != null && controller.getTransportControls() != null) {
            try {
                String action = intent.getAction();
                if (ACTION_PREVIOUS.equals(action)) {
                    controller.getTransportControls().skipToPrevious();
                } else if (ACTION_NEXT.equals(action)) {
                    controller.getTransportControls().skipToNext();
                } else if (ACTION_TOGGLE.equals(action)) {
                    PlaybackState state = controller.getPlaybackState();
                    if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
                        controller.getTransportControls().pause();
                    } else {
                        controller.getTransportControls().play();
                    }
                }
            } catch (SecurityException ignored) {
                // Media app may revoke or invalidate its session between widget taps.
            }
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> MusicWidgetProvider.updateAll(context), 300L);
    }
}

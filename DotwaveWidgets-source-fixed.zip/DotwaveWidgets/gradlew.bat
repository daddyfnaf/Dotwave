@echo off
setlocal
set VERSION=9.6.0
set CACHE=%USERPROFILE%\.gradle\dotwave-bootstrap\gradle-%VERSION%
if not exist "%CACHE%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\dotwave-bootstrap" mkdir "%USERPROFILE%\.gradle\dotwave-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%USERPROFILE%\.gradle\dotwave-bootstrap\gradle-%VERSION%.zip'; Expand-Archive -Force '%USERPROFILE%\.gradle\dotwave-bootstrap\gradle-%VERSION%.zip' '%USERPROFILE%\.gradle\dotwave-bootstrap'"
)
call "%CACHE%\bin\gradle.bat" -p "%~dp0" %*
endlocal

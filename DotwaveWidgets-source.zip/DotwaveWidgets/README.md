# Dotwave Widgets

A small Android home-screen widget pack combining Material You dynamic colour with restrained Nothing-inspired typography and dot details.

## Widgets

- **Music + lyrics (4×2):** square-cropped album artwork, track title and artist, playback controls and progress on the left; a short, high-contrast lyric excerpt on the right. Synced lyrics are fetched from LRCLIB when a matching entry exists.
- **Dot Clock (4×1):** local time and date, using the device's 12/24-hour preference and system date format. It refreshes on minute alarms and after system time/date/time-zone changes.

## Design notes

The interface deliberately avoids full-surface gradients, repeated nested cards, excessive blur and decorative effects without a function. It uses a single tonal surface, one divider, a compact type hierarchy and the device's dynamic Material colour roles.

## Build

Open the project in Android Studio and build the `app` debug variant. The project requires Android SDK 36 and JDK 17.

The GitHub Actions workflow can also build a debug APK from the source ZIP. The project folder inside the ZIP contains `settings.gradle.kts` and the `app` module.

Actual widget cell sizing can vary slightly by launcher and grid configuration. Add the Music + lyrics widget at 4×2 and Dot Clock at 4×1.

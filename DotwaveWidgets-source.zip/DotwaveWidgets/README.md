# Dotwave Widgets

A small Android widget pack with a **Material You + Nothing-inspired** visual style.

## Included in v1.0

- **Music Player:** album artwork, title, artist, previous/play-pause/next controls, progress bar, and a lyric line.
- **Dot Clock:** a monospaced clock and date with a dot-matrix label.
- **Dynamic colour:** Material 3 dynamic-colour themes are applied to the app and widget layouts on Android 12+ (API 31+). The widget theme uses the device's wallpaper/system colour scheme and follows light/dark mode.
- **Synced lyrics:** looks up track lyrics through LRCLIB. Timed lyrics advance while the track is playing. If only plain lyrics are available, a short text preview is shown instead.

## Install / run

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. From this folder, run `./gradlew wrapper --gradle-version 9.6.0` (Windows: `gradlew.bat wrapper --gradle-version 9.6.0`). The included bootstrap script downloads Gradle and generates the standard Gradle Wrapper files.
3. Open this folder (`DotwaveWidgets`) in Android Studio, let Gradle sync, then choose **Run** to install the app on your phone.
4. Open Dotwave Widgets and tap **Connect music access**. Android Settings will ask you to enable its notification-listener access. This is required to read active media sessions and send playback commands. You can revoke it from the same Settings screen.
5. Long-press an empty area on the home screen, open **Widgets**, find **Dotwave Widgets**, and add **Music Player** or **Dot Clock**.

You can also build from a terminal after Android SDK and Gradle dependencies are installed:

```bash
./gradlew assembleDebug
```

The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

## Lyrics behaviour

Lyrics are retrieved from `https://lrclib.net`. The app sends the track title, artist, album (when available), and duration to LRCLIB. A matching synced-lyrics record is required for line-by-line timing. Lyrics will not be available for every track. Music metadata and album artwork stay on-device; the lyrics lookup sends only the fields listed above.

## Notes

- Android 12+ is required for wallpaper-derived Material You dynamic colours. Older Android versions fall back to Material 3's default theme colours.
- Some music apps do not publish a MediaSession or do not expose all transport actions. Controls depend on what the currently active music app provides.
- The launcher controls widget resizing and available widget sizes. The player is designed for a medium/wide widget.
- The project source is provided; this environment does not have the Android SDK or Gradle installed, so an APK could not be compiled and device-tested here.

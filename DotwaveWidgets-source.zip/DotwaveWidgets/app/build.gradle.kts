plugins {
    id("com.android.application")
}

android {
    namespace = "dev.dotwave.widgets"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.dotwave.widgets"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.android.material:material:1.13.0")
}

package dev.dotwave.widgets;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.text.format.DateFormat;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Keeps the 4x1 clock widget in sync with the device's local time. */
public class ClockWidgetProvider extends AppWidgetProvider {
    private static final String ACTION_MINUTE_TICK = "dev.dotwave.widgets.CLOCK_MINUTE_TICK";
    private static final int ALARM_REQUEST_CODE = 4104;

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        updateIds(context, manager, appWidgetIds);
        scheduleNextMinute(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleNextMinute(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancelMinuteAlarm(context);
        super.onDisabled(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_MINUTE_TICK.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || Intent.ACTION_DATE_CHANGED.equals(action)) {
            updateAll(context);
            scheduleNextMinute(context);
            return;
        }
        super.onReceive(context, intent);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ClockWidgetProvider.class));
        if (ids.length == 0) return;
        updateIds(context, manager, ids);
        scheduleNextMinute(context);
    }

    private static void updateIds(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null || ids.length == 0) return;

        long now = System.currentTimeMillis();
        String time = DateFormat.getTimeFormat(context).format(new Date(now));
        String date = new SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(new Date(now));
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_clock);
        views.setTextViewText(R.id.clock_time, time);
        views.setTextViewText(R.id.clock_date, date);
        for (int id : ids) {
            manager.updateAppWidget(id, views);
        }
    }

    private static void scheduleNextMinute(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ClockWidgetProvider.class));
        if (ids.length == 0) return;

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, ClockWidgetProvider.class).setAction(ACTION_MINUTE_TICK);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                ALARM_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        long now = System.currentTimeMillis();
        long nextMinute = ((now / 60_000L) + 1L) * 60_000L;
        alarmManager.set(AlarmManager.RTC, nextMinute, pendingIntent);
    }

    private static void cancelMinuteAlarm(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        Intent intent = new Intent(context, ClockWidgetProvider.class).setAction(ACTION_MINUTE_TICK);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                ALARM_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();
    }
}

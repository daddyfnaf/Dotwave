package dev.dotwave.widgets;

import android.content.ComponentName;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MusicNotificationListener extends NotificationListenerService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService lyricsExecutor = Executors.newSingleThreadExecutor();
    private boolean connected;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!connected) return;
            boolean playing = syncPlayerState();
            handler.postDelayed(this, playing ? 1000L : 4000L);
        }
    };

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        connected = true;
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
        handler.removeCallbacks(ticker);
        super.onListenerDisconnected();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        refreshSoon();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        refreshSoon();
    }

    private void refreshSoon() {
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    private boolean syncPlayerState() {
        MediaController controller = findActiveController();
        if (controller == null) {
            PlayerStateStore.save(this, null);
            PlayerStateStore.setCurrentLyric(this, "Start music to see lyrics");
            MusicWidgetProvider.updateAll(this);
            return false;
        }

        PlayerStateStore.save(this, controller);
        MediaMetadata metadata = controller.getMetadata();
        String title = metadata == null ? "Unknown track" : safe(metadata.getString(MediaMetadata.METADATA_KEY_TITLE));
        String artist = metadata == null ? "Unknown artist" : safe(metadata.getString(MediaMetadata.METADATA_KEY_ARTIST));
        String album = metadata == null ? "" : safe(metadata.getString(MediaMetadata.METADATA_KEY_ALBUM));
        if (title.isEmpty()) title = "Unknown track";
        if (artist.isEmpty()) artist = "Unknown artist";
        long duration = metadata == null ? 0L : metadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        String trackKey = title + "\u001f" + artist + "\u001f" + album;

        if (!trackKey.equals(PlayerStateStore.getLyricsTrackKey(this))) {
            PlayerStateStore.saveLyrics(this, trackKey, "");
            PlayerStateStore.setCurrentLyric(this, "Looking up lyrics…");
            final String requestTitle = title;
            final String requestArtist = artist;
            final String requestAlbum = album;
            final long requestDuration = duration;
            lyricsExecutor.execute(() -> {
                String lyrics = LyricsClient.fetch(requestTitle, requestArtist, requestAlbum, requestDuration);
                if (trackKey.equals(PlayerStateStore.getLyricsTrackKey(this))) {
                    PlayerStateStore.saveLyrics(this, trackKey, lyrics);
                    long position = PlayerStateStore.prefs(this).getLong("position", 0L);
                    PlayerStateStore.setCurrentLyric(this, LyricsClient.currentLine(lyrics, position));
                    MusicWidgetProvider.updateAll(this);
                }
            });
        }

        long position = PlayerStateStore.prefs(this).getLong("position", 0L);
        String lyrics = PlayerStateStore.getLyrics(this);
        PlayerStateStore.setCurrentLyric(this,
                lyrics.trim().isEmpty() ? "Looking up lyrics…" : LyricsClient.currentLine(lyrics, position));
        MusicWidgetProvider.updateAll(this);

        PlaybackState state = controller.getPlaybackState();
        return state != null && state.getState() == PlaybackState.STATE_PLAYING;
    }

    static MediaController findActiveController(android.content.Context context) {
        try {
            MediaSessionManager manager = (MediaSessionManager) context.getSystemService(MEDIA_SESSION_SERVICE);
            if (manager == null) return null;
            ComponentName listener = new ComponentName(context, MusicNotificationListener.class);
            List<MediaController> sessions = manager.getActiveSessions(listener);
            if (sessions == null || sessions.isEmpty()) return null;

            MediaController fallback = null;
            for (MediaController session : sessions) {
                if (session.getMetadata() == null) continue;
                PlaybackState state = session.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) return session;
                if (fallback == null) fallback = session;
            }
            return fallback;
        } catch (SecurityException | IllegalStateException ignored) {
            return null;
        }
    }

    private static String safe(String value) {
        return value == null || value.trim().isEmpty() ? "" : value.trim();
    }
}
